$(function(){
    $('#back-btn-forget').click(function() {
        window.location.href = base_url+"admin/login";
        return
    });
})

/**
 * Created with JetBrains PhpStorm.
 * User: Mazhar
 * Date: 4/12/17
 * Time: 4:52 PM
 * To change this template use File | Settings | File Templates.
 */
$(document).ready(function () {

    if($('#title').length){
        tinymce.init({
            selector: '#title',
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor textcolor',
                'searchreplace visualblocks code fullscreen'
            ],
            toolbar: "bold italic forecolor | fontsizeselect fontselect",
            //font_formats: 'Arial=arial,helvetica,sans-serif;Courier New=courier new,courier,monospace;AkrutiKndPadmini=Akpdmi-n',
            fontsize_formats: "8pt 10pt 12pt 14pt 18pt 24pt 36pt",
            branding: false
        });
    }
    if($('#sub_title').length){
        tinymce.init({
            selector: '#sub_title',
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor textcolor',
                'searchreplace visualblocks code fullscreen'
            ],
            toolbar: "bold italic forecolor | fontsizeselect fontselect",
            //font_formats: 'Arial=arial,helvetica,sans-serif;Courier New=courier new,courier,monospace;AkrutiKndPadmini=Akpdmi-n',
            fontsize_formats: "8pt 10pt 12pt 14pt 18pt 24pt 36pt",
            branding: false
        });
    }


    if($('.tab_heading').length){
        tinymce.init({
            selector: '.tab_heading,.tab_content',
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor textcolor',
                'searchreplace visualblocks code fullscreen'
            ],
            toolbar: "bold italic forecolor | fontsizeselect fontselect",
            fontsize_formats: "8pt 10pt 12pt 14pt 18pt 24pt 36pt",
            branding: false
        });
    }

    if($('#content').length){
        tinymce.init({
            selector: '#content',
            height: 200,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor textcolor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table contextmenu paste code help'
            ],
            toolbar: 'insert | undo redo |  formatselect | bold italic forecolor fontsizeselect  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat fontselect',
            fontsize_formats: "8pt 10pt 12pt 14pt 18pt 24pt 36pt",
            branding: false
        });
    }

    if($('#site_title').length){
        tinymce.init({
            selector: '#site_title,#copyright_text',
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor textcolor',
                'searchreplace visualblocks code fullscreen'
            ],
            toolbar: "bold italic forecolor | fontsizeselect fontselect",
            fontsize_formats: "8pt 10pt 12pt 14pt 18pt 24pt 36pt",
            branding: false
        });
    }
    if($('#color_picker').length){
        $("#color_picker").spectrum({
            preferredFormat: "hex",
            showInput: true,
            showPalette: true,
            color: color
        });
    }

    $('input[type=file]').change(function () {
        var input=this;
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $(input).closest('.fileinput-new').find('img').attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    });

    if($('#removed').length){
        var remove_list=[];
        $('.remove').on('click',function(){
            var id=$(this).data('id');
            if(!remove_list.includes(id)){
                remove_list.push(id);
            }
            $('#removed').val(JSON.stringify(remove_list));
            $(this).closest('.fileinput-new').find('img').attr('src', 'http://www.placehold.it/200x150/EFEFEF/AAAAAA&text=no+image');
            $('input[name=image'+id+']').val('');
        })
    }

    if($('#practicing').length){
        $('#practicing').DataTable();
    }



});

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $(input).closest('.fileinput-new').find('img').attr('src', e.target.result);
        };

        reader.readAsDataURL(input.files[0]);
    }
}
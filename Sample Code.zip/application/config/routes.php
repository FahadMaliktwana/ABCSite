<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['admin/social_links'] = 'Admin_inner/social_links';
$route['admin/nav/(:num)'] = 'Admin_inner/nav/$1';
$route['admin/slider/(:num)'] = 'Admin_inner/slider/$1';
$route['admin/about'] = 'Admin_inner/about';

$route['admin/services'] = 'Admin_inner/services';
$route['admin/service_content'] = 'Admin_inner/service_content';
$route['admin/add_service'] = 'Admin_inner/add_service';
$route['admin/add_service/(:num)'] = 'Admin_inner/add_service/$1';
$route['admin/delete_service/(:num)'] = 'Admin_inner/delete_service/$1';

$route['admin/skills'] = 'Admin_inner/skills';
$route['admin/skill_content'] = 'Admin_inner/skill_content';
$route['admin/add_skill'] = 'Admin_inner/add_skill';
$route['admin/add_skill/(:num)'] = 'Admin_inner/add_skill/$1';
$route['admin/delete_skill/(:num)'] = 'Admin_inner/delete_skill/$1';

$route['admin/clients'] = 'Admin_inner/clients';
$route['admin/client_content'] = 'Admin_inner/client_content';
$route['admin/add_client'] = 'Admin_inner/add_client';
$route['admin/add_client/(:num)'] = 'Admin_inner/add_client/$1';
$route['admin/delete_client/(:num)'] = 'Admin_inner/delete_client/$1';

$route['admin/portfolio'] = 'Admin_inner/portfolio';
$route['admin/setting'] = 'Admin_inner/setting';
$route['admin/profile'] = 'Admin_inner/profile';
$route['admin/start'] = 'Admin_inner/start';
$route['admin/newsletter'] = 'Admin_inner/newsletter';
$route['admin/request'] = 'Admin_inner/request';
$route['admin/twitter'] = 'Admin_inner/twitter';
$route['admin/smtp'] = 'Admin_inner/smtp_settings';

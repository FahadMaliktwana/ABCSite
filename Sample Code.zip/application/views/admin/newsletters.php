<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEAD-->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>NewsLetter Subscriber</h1>
            </div>
            <!-- END PAGE TITLE -->
        </div>
        <!-- BEGIN PAGE CONTENT INNER -->
        <div class="page-content-inner">
            <div class="row">
                <div class="col-md-12">
                    <!-- BEGIN CONDENSED TABLE PORTLET-->
                    <div class="portlet light ">
                        <div class="portlet-title">
                            <div class="caption font-dark">
                                <i class="icon-settings font-dark"></i>
                                <span class="caption-subject bold uppercase"> NewsLetter Subscriber</span>
                            </div>
                        </div>
                        <div class="portlet-body">
                           <div id="sample_1_wrapper" class="dataTables_wrapper no-footer">
                                <table class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" id="practicing" role="grid" aria-describedby="sample_1_info">
                                    <thead>
                                    <tr role="row">
                                        <th> # </th>
                                        <th> Email Address </th>
                                        <th> Created At </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($data as $index=>$client){
                                        ?>
                                    <tr class="odd">
                                        <td> <?= $index+1;?> </td>
                                        <td> <?= isset($client['email'])?$client['email']:'';?> </td>
                                        <td> <?= isset($client['created_at'])?date('m-d-Y',$client['created_at']):'';?> </td>
                                    </tr>
                                        <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END CONDENSED TABLE PORTLET-->
            </div>
            <!-- END SAMPLE FORM PORTLET-->
        </div>

    </div>
    <!-- END CONTAINER -->
</div>
<div class="content">
    <!-- BEGIN LOGIN FORM -->

    <!-- BEGIN LOGIN FORM -->
    <form action="<?php echo site_url('admin/forgotpassword'); ?>" method="post">
        <h3 class="font-green">Forget Password ?</h3>
        <?php if (validation_errors() != false || $loginError) { ?>
        <div class="alert alert-danger"> <button class="close" data-close="alert"></button> <?php echo validation_errors() . $loginError; ?> </div>
        <?php } else if (isset($success)&&$success == 1) { ?>
        <div class="alert alert-success"> <button class="close" data-close="alert"></button> <span>Reset Link Sent Successfully on your Email account!</span> </div>
        <?php }
        ?>
        <p> Enter your e-mail address below to reset your password. </p>
        <div class="form-group">
            <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="Email" name="email" required />
        </div>
        <div class="form-actions">
<!--            <button type="button" id="back-btn" class="btn green btn-outline">Back</button>-->
            <a href="<?= base_url('admin/login');?>" class="btn default"> Back </a>
            <input type="submit" name="admin_forgot_form" value="submit" class="btn btn-success uppercase pull-right"/>
        </div>
    </form>
</div>
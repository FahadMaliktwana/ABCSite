<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEAD-->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Manage Client</h1>
            </div>
            <!-- END PAGE TITLE -->
        </div>
                    <!-- BEGIN PAGE CONTENT INNER -->
                    <div class="page-content-inner">
                        <div class="row">
                            <div class="col-md-12 ">
                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                <div class="portlet light ">
                                    <div class="portlet-title">
                                        <div class="caption">
                                            <i class="icon-settings font-dark"></i>
                                            <span class="caption-subject font-dark sbold uppercase">Manage Clients</span>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <?php
                                        if(validation_errors()){
                                            ?>
                                            <div class="col-md-9 col-md-offset-3">
                                                <div class="alert alert-danger alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                                    <?php echo validation_errors(); ?>
                                                </div>
                                            </div>
                                            <?php
                                        }

                                        if(isset($error)){
                                            ?>
                                            <div class="col-md-9 col-md-offset-3">
                                                <div class="alert alert-danger alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                                    <?php echo $error; ?>
                                                </div>
                                            </div>
                                            <?php
                                        }

                                        if(isset($success)){
                                            ?>
                                            <div class="col-md-9 col-md-offset-3">
                                                <div class="alert alert-success alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                                    <?php echo $success; ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <form class="form-horizontal" action="" method="post" role="form">
                                            <div class="form-body">
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Title</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control" name="title" id="title" rows="1"><?= isset($data['title'])?$data['title']:''; ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">Content</label>
                                                <div class="col-md-9">
                                                    <textarea class="form-control" id="content" name="content" rows="1"><?= isset($data['content'])?$data['content']:''; ?></textarea>
                                                </div>
                                            </div>

                                    </div>
                                    <div class="form-actions">
                                        <div class="row">
                                            <div class="col-md-offset-3 col-md-9">
                                                <button type="submit" class="btn green">Submit</button>
                                                <a href="<?= base_url('admin'); ?>" class="btn default">Cancel</a>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                        </div>
                    </div>

    </div>
</div>
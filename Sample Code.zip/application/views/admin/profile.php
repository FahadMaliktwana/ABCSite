<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEAD-->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Manage Profile</h1>
            </div>
            <!-- END PAGE TITLE -->
        </div>
                <div class="page-content-inner">
                <div class="portlet light ">
                <div class="tabbable-line tabbable-full-width">
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="#tab_1_3" data-toggle="tab" aria-expanded="true"> Account </a>
                    </li>
                </ul>
                <div class="tab-content">
                <!--tab_1_2-->
                <div class="tab-pane active" id="tab_1_3">
                    <div class="row profile-account">
                        <div class="col-md-3">
                            <ul class="ver-inline-menu tabbable margin-bottom-10">
                                <li class="<?= (isset($active)&&$active!='profile')?'':'active';?>">
                                    <a data-toggle="tab" href="#tab_1-1" aria-expanded="false">
                                        <i class="fa fa-cog"></i> Personal info </a>
                                    <span class="after"> </span>
                                </li>
                                <li class="<?= (isset($active)&&$active=='password')?'active':'';?>">
                                    <a data-toggle="tab" href="#tab_3-3" aria-expanded="true">
                                        <i class="fa fa-lock"></i> Change Password </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-9">
                            <?php
                            if(validation_errors()){
                                ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                    <?php echo validation_errors(); ?>
                                </div>
                                <?php
                            }
                            if(isset($success)){
                                ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                    <?php echo $success; ?>
                                </div>
                                <?php
                            }
                            ?>
                            <div class="tab-content">
                                <div id="tab_1-1" class="tab-pane <?= (isset($active)&&$active!='profile')?'':'active';?>">
                                    <form role="form" action="" method="post">
                                        <div class="form-group">
                                            <label class="control-label">First Name</label>
                                            <input type="text" placeholder="John" name="first_name" class="form-control" value="<?= isset($admin['first_name'])?$admin['first_name']:'';?>" required/>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Last Name</label>
                                            <input type="text" placeholder="Doe" name="last_name" value="<?= isset($admin['last_name'])?$admin['last_name']:'';?>" class="form-control" required/>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Email</label>
                                            <input type="email" placeholder="xyz@mail.com" name="email" class="form-control" value="<?= isset($admin['email'])?$admin['email']:'';?>" required/>
                                        </div>
                                        <div class="margiv-top-10">
                                            <input type="submit" class="btn green" value="Save Changes" name="profile"/>
                                            <a href="<?= base_url('admin'); ?>" class="btn default"> Cancel </a>
                                        </div>
                                    </form>
                                </div>
                                <div id="tab_3-3" class="tab-pane <?= (isset($active)&&$active=='password')?'active':'';?>">
                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label class="control-label">New Password</label>
                                            <input type="password" name="password" required="" class="form-control" />
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Re-type New Password</label>
                                            <input type="password" name="confirm_password" required="" class="form-control" />
                                        </div>
                                        <div class="margin-top-10">
                                            <input type="submit" class="btn green" value="Change Password" name="admin_change_form"/>
                                            <a href="<?= base_url('admin'); ?>" class="btn default"> Cancel </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!--end col-md-9-->
                    </div>
                </div>
                <!--end tab-pane-->
                </div>
                </div>
                </div>
                </div>

</div>
<!-- END CONTAINER -->
</div>
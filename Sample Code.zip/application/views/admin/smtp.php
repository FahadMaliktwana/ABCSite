<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEAD-->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Manage SMTP</h1>
            </div>
            <!-- END PAGE TITLE -->
        </div>
        <!-- BEGIN PAGE CONTENT INNER -->
        <div class="page-content-inner">
            <div class="row">
                <div class="col-md-12 ">
                    <!-- BEGIN SAMPLE FORM PORTLET-->
                    <div class="portlet light ">
                        <div class="portlet-title">
                            <div class="caption">
                                <i class="icon-settings font-dark"></i>
                                <span class="caption-subject font-dark sbold uppercase">Manage SMTP Settings</span>
                            </div>
                        </div>
                        <div class="portlet-body form">
                            <?php
                            if(validation_errors()){
                                ?>
                                <div class="col-md-9 col-md-offset-3">
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                        <?php echo validation_errors(); ?>
                                    </div>
                                </div>
                                <?php
                            }

                            if(isset($success)){
                                ?>
                                <div class="col-md-9 col-md-offset-3">
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                        <?php echo $success; ?>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                            <form class="form-horizontal" action="" method="post" role="form">
                                <div class="form-body">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">SMTP Host</label>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-inline input-medium" placeholder="SMTP Host" name="host" value="<?= isset($data['host'])?$data['host']:''; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">SMTP Username</label>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-inline input-medium" placeholder="SMTP Username" name="username" value="<?= isset($data['username'])?$data['username']:''; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">SMTP Password</label>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-inline input-medium" placeholder="SMTP Password" name="password" value="<?= isset($data['password'])?base64_decode($data['password']):''; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">SMTP Port</label>
                                        <div class="col-md-6">
                                            <div class="input-group">
                                                <input type="text" class="form-control input-inline input-medium" placeholder="SMTP Port" name="port" value="<?= isset($data['port'])?$data['port']:''; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-actions">
                                    <div class="row">
                                        <div class="col-md-offset-3 col-md-9">
                                            <button type="submit" class="btn green">Submit</button>
                                            <a href="<?= base_url('admin'); ?>" class="btn default">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
                <!-- END SAMPLE FORM PORTLET-->
            </div>
        </div>

    </div>
    <!-- END CONTAINER -->
</div>
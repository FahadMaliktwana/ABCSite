<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEAD-->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Manage Services</h1>
            </div>
            <!-- END PAGE TITLE -->
        </div>
                    <!-- BEGIN PAGE CONTENT INNER -->
                    <div class="page-content-inner">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN CONDENSED TABLE PORTLET-->
                                <div class="portlet light ">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> Services</span>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                <div class="table-toolbar">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="btn-group">
                                                <a href="<?= base_url('admin/add_service'); ?>" class="btn sbold green"><i class="fa fa-plus"></i> Add New</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <?php
                                    if($this->session->flashdata('error')){
                                        ?>
                                        <div class="alert alert-danger alert-dismissable">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                            <?php echo $this->session->flashdata('error'); ?>
                                        </div>
                                        <?php
                                    }

                                    if($this->session->flashdata('success')){
                                        ?>
                                        <div class="alert alert-success alert-dismissable">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                            <?php echo $this->session->flashdata('success'); ?>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                <div id="sample_1_wrapper" class="dataTables_wrapper no-footer">
                                <table class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" id="practicing" role="grid" aria-describedby="sample_1_info">
                                <thead>
                                <tr role="row">
                                    <th> # </th>
                                    <th> Title </th>
                                    <th> Created At </th>
                                    <th> Action </th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($data as $index=>$service){
                                    ?>
                                <tr class="odd">
                                    <td> <?= $index+1;?> </td>
                                    <td> <?= isset($service['title'])?strip_tags($service['title']):'';?> </td>
                                    <td> <?= isset($service['created_at'])?date('m-d-Y',$service['created_at']):'';?> </td>
                                    <td>
                                        <a href="<?= base_url('admin/add_service/'.$service['id']);?>"><i class="fa fa-pencil" aria-hidden="true"></i> Edit</a>
                                        &nbsp;<a href="<?= base_url('admin/delete_service/'.$service['id']);?>" onclick="return confirm('Are you sure you want to delete this Record?');"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</a>
                                    </td>
                                </tr>
                                    <?php
                                }
                                ?>
                                </tbody>
                                </table>
                                </div>
                                </div>
                                </div>
                                </div>
                                <!-- END CONDENSED TABLE PORTLET-->
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                        </div>

    </div>

</div>

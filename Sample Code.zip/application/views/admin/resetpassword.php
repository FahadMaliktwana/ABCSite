<div class="content">
        <!-- BEGIN LOGIN FORM -->
    <form action="<?php echo site_url('admin/resetpassword/' . $rCode); ?>" method="post">
            <h3 class="form-title font-green">Reset Your Password</h3>
            <?php if (validation_errors() != false || $loginError) { ?>
            <button class="close" data-close="alert"></button>
            <div class="alert alert-danger"> <?php echo validation_errors() . $loginError; ?> </div>
           <?php
              }

        if ($resetCodeValid) {
            ?>
            <div class="form-group">
                <label class="control-label visible-ie8 visible-ie9">Password</label>
                <input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off" required="" placeholder="Password" name="password" />
            </div>
            <div class="form-group">
                <label class="control-label visible-ie8 visible-ie9">Confirm Password</label>
                <input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off" required="" placeholder="Confirm Password" name="confirm_password" />
            </div>
            <div class="form-actions">
                <a href="<?= base_url('admin/login');?>" class="btn default"> Cancel </a>
                <input type="submit" class="btn btn-success uppercase pull-right" name="admin_reset_form" value="Reset">
            </div>
            <?php
        }
            ?>

    </form>
</div>
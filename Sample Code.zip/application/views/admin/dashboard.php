<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEAD-->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
            <!-- END PAGE TITLE -->
        </div>
        <!-- END PAGE HEAD-->
        <!-- BEGIN PAGE BASE CONTENT -->
        <!-- BEGIN PAGE CONTENT BODY -->

        <!-- BEGIN PAGE CONTENT INNER -->
        <div class="page-content-inner">
            <div class="row">
                <div class="col-md-12 ">
                    <!--                            <div class="col-md-offset-1 col-md-9">-->
                    <div class="portlet light">
                        <h2 class="text-center">Welcome to CMS</h2>
                        <h5 class="text-center">Please Use Left menu for content edition.</h5>
                    </div>
                    <!--                            </div>-->
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT BODY -->
        <!-- END PAGE BASE CONTENT -->
    </div>
    <!-- END CONTENT BODY -->
</div>
<div class="page-content-wrapper">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE HEAD-->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h1>Manage Work Section</h1>
            </div>
            <!-- END PAGE TITLE -->
        </div>
                    <!-- BEGIN PAGE CONTENT INNER -->
                    <div class="page-content-inner">
                        <div class="row">
                            <div class="col-md-12 ">
                                <!-- BEGIN SAMPLE FORM PORTLET-->
                                <div class="portlet light ">
                                    <div class="portlet-title">
                                        <div class="caption">
                                            <i class="icon-settings font-dark"></i>
                                            <span class="caption-subject font-dark sbold uppercase">Work Section</span>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <?php
                                        if(validation_errors()){
                                            ?>
                                            <div class="col-md-9 col-md-offset-3">
                                                <div class="alert alert-danger alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                                    <?php echo validation_errors(); ?>
                                                </div>
                                            </div>
                                            <?php
                                        }

                                        if(isset($error)){
                                            ?>
                                            <div class="col-md-9 col-md-offset-3">
                                                <div class="alert alert-danger alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                                    <?php echo $error; ?>
                                                </div>
                                            </div>
                                            <?php
                                        }

                                        if(isset($success)){
                                            ?>
                                            <div class="col-md-9 col-md-offset-3">
                                                <div class="alert alert-success alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                                                    <?php echo $success; ?>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <form class="form-horizontal" method="post" action="" enctype="multipart/form-data" role="form">
                                            <div class="form-body">
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Title</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control" id="title" name="title" rows="1"><?= isset($data['title'])?$data['title']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Sub Title</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control" id="sub_title" name="sub_title" rows="1"><?= isset($data['content'])?$data['content']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Tab1 Heading</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control tab_heading"  name="tab1_heading" rows="1"><?= isset($data['tab1_heading'])?$data['tab1_heading']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Tab1 Content</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control tab_content"  name="tab1_content" rows="1"><?= isset($data['tab1_content'])?$data['tab1_content']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Tab2 Heading</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control tab_heading"  name="tab2_heading" rows="1"><?= isset($data['tab2_heading'])?$data['tab2_heading']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Tab2 Content</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control tab_content"  name="tab2_content" rows="1"><?= isset($data['tab2_content'])?$data['tab2_content']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Tab3 Heading</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control tab_heading"  name="tab3_heading" rows="1"><?= isset($data['tab3_heading'])?$data['tab3_heading']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Tab3 Content</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control tab_content"  name="tab3_content" rows="1"><?= isset($data['tab3_content'])?$data['tab3_content']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Tab4 Heading</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control tab_heading"  name="tab4_heading" rows="1"><?= isset($data['tab4_heading'])?$data['tab4_heading']:''; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Tab4 Content</label>
                                                    <div class="col-md-9">
                                                        <textarea class="form-control tab_content"  name="tab4_content" rows="1"><?= isset($data['tab4_content'])?$data['tab4_content']:''; ?></textarea>
                                                    </div>
                                                </div>
<!--                                            <div class="form-group">-->
<!--                                                <label class="col-md-3 control-label">Select Image</label>-->
<!---->
<!--                                                <div class="col-md-3">-->
<!--                                                    <div class="fileinput fileinput-new" data-provides="fileinput">-->
<!--                                                        <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">-->
<!--                                                            <img src="--><?//= (isset($data['image'])&&!empty($data['image']))?base_url('uploads/'.$data['image']):'http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image'; ?><!--" style="width: 200px; height: 143px;" alt="" >-->
<!--                                                        </div>-->
<!--                                                        <div>-->
<!--                                                        <span class="btn default btn-file">-->
<!--                                                        <span class="fileinput-new"> Select image </span>-->
<!--                                                        <input type="file" name="image"></span>-->
<!--                                                        </div>-->
<!--                                                    </div>-->
<!--                                                </div>-->
<!--                                            </div>-->

                                    </div>
                                    <div class="form-actions">
                                        <div class="row">
                                            <div class="col-md-offset-3 col-md-9">
                                                <button type="submit" class="btn green">Submit</button>
                                                <a href="<?= base_url('admin'); ?>" class="btn default">Cancel</a>
                                            </div>
                                        </div>
                                    </div>

                                    </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                        </div>
                    </div>

</div>
<!-- END CONTAINER -->
</div>
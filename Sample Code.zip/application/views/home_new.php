<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= (isset($settings['site_title'])&&!empty($settings['site_title']))?strip_tags($settings['site_title']):'Welcome';?></title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <link href="<?php echo site_url('assets/public/css/bootstrap.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/public/css/font-awesome.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/public/css/slick.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/public/css/style.css'); ?>" rel="stylesheet">
</head>

<body  data-spy="scroll" data-target=".as-navbar" data-offset="50">


    <nav class="navbar navbar-default as-navbar" data-spy="affix" data-offset-top="10">
        <div class="container">
            <div class="nav-table">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header nav-cell mb-table">
                    <a class="navbar-brand" href="#">
                        <img src="<?= ((isset($settings['logo'])&&!empty($settings['logo'])))?base_url('uploads/'.$settings['logo']):site_url('assets/public/images/logo.png'); ?>" class="img-responsive">
                    </a>
                    <div class="nav-button">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="nav-cell">
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-right as-nav smooth-scroll">
                            <li class="active"><a href="#top"><?= (search_collection($nav, 'id', 1))?search_collection($nav, 'id', 1)['title']:'Home'; ?></a></li>
                            <li><a href="#services"><?= (search_collection($nav, 'id', 2))?search_collection($nav, 'id', 2)['title']:'Our Services'; ?></a></li>
                            <li><a href="#about"><?= (search_collection($nav, 'id', 3))?search_collection($nav, 'id', 3)['title']:'About Us'; ?></a></li>
                            <li><a href="#contact"><?= (search_collection($nav, 'id', 4))?search_collection($nav, 'id', 4)['title']:'Contact Us'; ?></a></li>
                        </ul>
                    </div>
                    <!-- /.navbar-collapse -->
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </nav>



<!-- MAIN SLIDER -->
<header id="top">
<section class="slide-wrapper">
    <div class="slider-container">
        <div id="myCarousel" class="carousel slide">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item item1 active">
                    <div class="fill" style="background: linear-gradient(0deg, rgba(20,56,142,0.3), rgba(20,56,142,0.3)), url('<?=(isset($slide1)&&!empty($slide1['image']))?base_url('uploads/'.$slide1['image']):asset_url('public/images/slide-1.jpg'); ?>') no-repeat;">
                        <div class="inner-content">
                            <div class="container">
                                <div class="carousel-desc">

                                    <h2 style="word-break: break-all;"><?=(isset($slide1)&&!empty($slide1['title']))?$slide1['title']:'We Are <span class="slider-red-bold">Niquetribe</span> One Parallax Page'; ?></h2>
                                    <?= (isset($slide1)&&!empty($slide1['content']))?$slide1['content']:''; ?>
                                    <a href="#about" class="btn btn-default black-btn">Learn More</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item item2">
                    <div class="fill" style="background: linear-gradient(0deg, rgba(20,56,142,0.3), rgba(20,56,142,0.3)), url('<?=(isset($slide2)&&!empty($slide2['image']))?base_url('uploads/'.$slide2['image']):asset_url('public/images/slide-1.jpg'); ?>') no-repeat;">
                        <div class="inner-content">
                            <div class="container">
                                <div class="carousel-desc">

                                    <h2 style="word-break: break-all;"><?=(isset($slide2)&&!empty($slide2['title']))?$slide2['title']:'We Are <span class="slider-red-bold">Niquetribe</span> One Parallax Page'; ?></h2>
                                    <?= (isset($slide2)&&!empty($slide2['content']))?$slide2['content']:''; ?>
                                    <a href="#about" class="btn btn-default black-btn">Learn More</a>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</header>
<!-- END MAIN SLIDER -->

<div class="page-content">

<!-- ABOUT SECTION -->
<div class="section" id="about">
    <div class="container">
        <div class="section-heading">
            <h2 class="heading"><?= (isset($about['title'])&&!empty($about['title']))?$about['title']:"About Us";?></h2>
        </div>

        <div class="section-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="about-content">
                        <?= (isset($about['content'])&&!empty($about['content']))?$about['content']:"";?></h2>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- END ABOUT SECTION -->



<!-- PROCESS SECTION -->
<div class="section" id="services">
    <div class="container">

        <div class="section-content">
            <div class="section-heading">
                <?= (search_collection($sections, 'id', 1))?'<h4 class="sub-heading">'.search_collection($sections, 'id', 1)['content'].'</h4>':''; ?></h4>
                <?= (search_collection($sections, 'id', 1))?'<h2 class="heading">'.search_collection($sections, 'id', 1)['title'].'</h2>':''; ?>

<!--                <h4 class="sub-heading">WHAT WE DO</h4>-->
<!--                <h2 class="heading">Our Services</h2>-->
            </div>
            <div class="row">

                <div class="col-md-12">
                    <div class="process-tabs">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <?php
                            if(isset($services)&&count($services)>0){
                                foreach($services as $index=>$service){
                                    ?>

                                    <li role="presentation" class="<?= ($index==0)?'active':'';?>">
                                        <a href="#tab_<?= ($index+1);?>" aria-controls="briefing" role="tab" data-toggle="tab">
                                            <span class="tab-img-title">
                                                <h3><?= (isset($service['title'])&&!empty($service['title']))?$service['title']:"";?></h3>
                                            </span>
                                        </a>
                                    </li>
                                    <?php
                                }
                            }
                            ?>

                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content">
                            <?php
                            if(isset($services)&&count($services)>0){
                                foreach($services as $index=>$service){
                                    ?>
                                    <div role="tabpanel" class="tab-pane <?= ($index==0)?'active':'';?>" id="tab_<?= ($index+1);?>">
                                        <div class="process-content">
                                            <div class="row">
                                                <div class="col-md-1">
                                                    <div class="service-image">
                                                        <img src="<?=(isset($service['logo'])&&!empty($service['logo']))?base_url('uploads/'.$service['logo']):asset_url('public/images/web-design.png'); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-10">
                                                    <?= (isset($service['content']))?$service['content']:"";?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END PROCESS SECTION -->





<!-- CLIENT SECTION -->
<?php
if(isset($tweets)){
    ?>
<div class="section" id="clients">
    <div class="container">

        <div class="section-heading">
            <h2 class="heading"><?= isset($tweet_title)?$tweet_title:"";?></h2>
        </div>

        <div class="client-slider-main">

            <div class="client-slider-navigation">
                <a href="#" class="previous_arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                <a href="#" class="next_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            </div>

            <div class="client-slider">

                     <?php
            if(isset($tweets)){
                foreach($tweets->channel->item as $Item){
                    ?>
                    <div class="client-testimonial">
                    <div class="testimonial-content">
                        <p><?= isset($Item->title)?$Item->title:''; ?></p>
                    </div>

                    <div class="client-info">
                        <img style="max-width: 100px" src="<?= isset($tweet_image)?$tweet_image:asset_url('public/images/tweet-icon.png'); ?>" class="img-circle">
                        <h3 class="client-name">@<?= isset($tweet_username)?$tweet_username:'';?></h3>
                    </div>
                    </div>
                        <?php
                }
            }
                    ?>

            </div>
        </div>
    </div>
</div>
    <?php
}else{
    ?>
    <div class="section" id="clients">
    <div class="container">

        <div class="section-heading">
            <h2 class="heading"><?= isset($tweet_title)?$tweet_title:"";?></h2>
        </div>

        <div class="client-slider-main">

            <div class="client-slider-navigation">
                <a href="#" class="previous_arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                <a href="#" class="next_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            </div>

            <div class="client-slider">
                <div class="client-testimonial">
                    <div class="testimonial-content">
                        <p>Lorem ipsum dolor sit amet consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.  </p>
                    </div>

                    <div class="client-info">
                        <img src="<?= asset_url('public/images/tweet-icon.png'); ?>" class="img-circle">
                        <h3 class="client-name">@username</h3>
                    </div>
                </div>

                <div class="client-testimonial">
                    <div class="testimonial-content">
                        <p>Lorem ipsum dolor sit amet consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.  </p>
                    </div>

                    <div class="client-info">
                        <img src="<?= asset_url('public/images/tweet-icon.png'); ?>" class="img-circle">
                        <h3 class="client-name">@username</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
        <?php
}
    ?>
<!-- END CLIENT SECTION -->


<!-- GET IN TOUCH SECTION -->
<div class="git-section" id="contact">
    <div class="container">
        <div class="section-heading">
            <h2 class="heading"><?= (search_collection($nav, 'id', 4))?search_collection($nav, 'id', 4)['title']:'Contact Us'; ?></h2>

        </div>
        <div class="row">
            <?php
            if($this->session->flashdata('error')){
                ?>
                <div class="alert alert-danger">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <?= $this->session->flashdata('error'); ?>
                </div>
                <?php
            }
            if($this->session->flashdata('success')){
                ?>
                <div class="alert alert-success">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <?= $this->session->flashdata('success'); ?>
                </div>
                <?php
            }
            ?>
            <div class="git-form">
                <form action="" method="post">
                    <div class="form-field">
                        <input type="text" name="name" placeholder="Your Name*" required="">
                    </div>

                    <div class="form-field">
                        <input type="email" name="email" placeholder="Email Address*" required="">
                    </div>

                    <div class="form-field">
                        <input type="text" name="subject" placeholder="Subject"required="">
                    </div>

                    <div class="form-field">
                        <textarea name="message" required="" placeholder="Write Message*"></textarea>
                    </div>

                    <div class="form-field">
                        <button type="submit" class="btn btn-default git-btn">Send Message</button>
                    </div>
                </form>
            </div>
        </div>




    </div>

    <div class="clearfix"></div>
</div>

<!-- END GET IN TOUCH SECTION -->


<div class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="col-sm-6 col-md-3">
                <div class="widget">
                    <h3 class="widget-heading">Quick Links</h3>

                    <ul class="widget-list">
                        <li><a href="#myCarousel"><?= (search_collection($nav, 'id', 1))?search_collection($nav, 'id', 1)['title']:'Home'; ?></a></li>
                        <li><a href="#services"><?= (search_collection($nav, 'id', 2))?search_collection($nav, 'id', 2)['title']:'Our Services'; ?></a></li>
                        <li><a href="#about"><?= (search_collection($nav, 'id', 3))?search_collection($nav, 'id', 3)['title']:'About Us'; ?></a></li>
                        <li><a href="#contact"><?= (search_collection($nav, 'id', 4))?search_collection($nav, 'id', 4)['title']:'Contact Us'; ?></a></li>
                    </ul>
                </div>
            </div>

            <div class="col-sm-6 col-md-offset-6 col-md-3">
                <div class="widget">
                    <h3 class="widget-heading">Newsletter</h3>

                    <div class="widget-form">
                        <form action=""method="post">
                            <i class="fa fa-paper-plane"></i>
                            <input type="email" name="email" required="" placeholder="Email Address" class="footer-newsletter">
                        </form>
                    </div>
                    <ul class="widget-list footer-social-links">
                        <li><a href="<?= (isset($social_links['facebook'])&&!empty($social_links['facebook']))?$social_links['facebook']:'javascript:void(0);';?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="<?= (isset($social_links['twitter'])&&!empty($social_links['twitter']))?$social_links['twitter']:'javascript:void(0);';?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="<?= (isset($social_links['linkedin'])&&!empty($social_links['linkedin']))?$social_links['linkedin']:'javascript:void(0);';?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                    </ul>
                    <ul class="widget-list icon-list">
                        <?= ((isset($settings['email'])&&!empty($settings['email'])))?'<li><a href="mailto:'.((isset($settings['email'])&&!empty($settings['email']))?strip_tags($settings['email']):'javascript:void(0);').'"><i class="fa fa-envelope-o" aria-hidden="true"></i>' .$settings['email'].'</a></li>':""; ?>
                    </ul>

                </div>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <p><?= (isset($settings['copyright_text'])&&!empty($settings['copyright_text']))?$settings['copyright_text']:"IT Services 2017 All Rights Reserved.";?></p>
        </div>
    </div>
</div>
</div>

<!-- STICKY ICONS -->
<div class="sticky-icons-wrapper">
    <ul class="sticky-social-icons">
        <li id="sticky-fb"><a href="<?= (isset($social_links['facebook'])&&!empty($social_links['facebook']))?$social_links['facebook']:'javascript:void(0);';?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li id="sticky-twitter"><a href="<?= (isset($social_links['twitter'])&&!empty($social_links['twitter']))?$social_links['twitter']:'javascript:void(0);';?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
        <li id="sticky-linkedin"><a href="<?= (isset($social_links['linkedin'])&&!empty($social_links['linkedin']))?$social_links['linkedin']:'javascript:void(0);';?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
    </ul>
</div>

<script src="<?php echo site_url('assets/public/js/jquery-3.2.1.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/public/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/public/js/slick.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/public/js/custom.js'); ?>"></script>
</body>

</html>

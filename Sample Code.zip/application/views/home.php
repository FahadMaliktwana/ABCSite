<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= (isset($settings['site_title'])&&!empty($settings['site_title']))?strip_tags($settings['site_title']):'Welcome';?></title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <link href="<?php echo site_url('assets/public/css/bootstrap.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/public/css/font-awesome.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/public/css/slick.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/public/css/style.css'); ?>" rel="stylesheet">
</head>

<body>

<div class="header">
    <nav class="navbar navbar-default as-navbar">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="<?= ((isset($settings['logo'])&&!empty($settings['logo'])))?base_url('uploads/'.$settings['logo']):site_url('assets/public/images/logo.png'); ?>" class="logo">
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right as-nav">
                    <ul class="nav navbar-nav navbar-right as-nav">
                        <li class="active"><a href="#"><?= (search_collection($nav, 'id', 1))?search_collection($nav, 'id', 1)['title']:'Home'; ?></a></li>
                        <li><a href="#service"><?= (search_collection($nav, 'id', 2))?search_collection($nav, 'id', 2)['title']:'Our Services'; ?></a></li>
                        <li><a href="#about"><?= (search_collection($nav, 'id', 3))?search_collection($nav, 'id', 3)['title']:'About Us'; ?></a></li>
                        <li><a href="#contact"><?= (search_collection($nav, 'id', 4))?search_collection($nav, 'id', 4)['title']:'Contact Us'; ?></a></li>
                    </ul>
            </div>
        </div>
    </nav>
</div>

<!-- MAIN SLIDER -->
<section class="slide-wrapper">
    <div class="slider-container">
        <div id="myCarousel" class="carousel slide">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item item1 active">
                    <div class="fill" style="background: linear-gradient(0deg, rgba(20,56,142,0.3), rgba(20,56,142,0.3)), url(<?=(isset($slide1)&&!empty($slide1['image']))?base_url('uploads/'.$slide1['image']):asset_url('public/images/slide-1.jpg'); ?>) no-repeat;">
                        <div class="inner-content">
                            <div class="container">
                                <div class="carousel-desc">

                                    <h2 style="word-break: break-all;"><?=(isset($slide1)&&!empty($slide1['title']))?$slide1['title']:'We Are <span class="slider-red-bold">Niquetribe</span> One Parallax Page'; ?></h2>
                                    <?= (isset($slide1)&&!empty($slide1['content']))?$slide1['content']:''; ?>
                                    <a href="#about" class="btn btn-default black-btn">Learn More</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item item2">
                    <div class="fill" style="background: linear-gradient(0deg, rgba(20,56,142,0.3), rgba(20,56,142,0.3)), url(<?=(isset($slide2)&&!empty($slide2['image']))?base_url('uploads/'.$slide2['image']):asset_url('public/images/slide-1.jpg'); ?>) no-repeat;">
                        <div class="inner-content">
                            <div class="container">
                                <div class="carousel-desc">

                                    <h2 style="word-break: break-all;"><?=(isset($slide2)&&!empty($slide2['title']))?$slide2['title']:'We Are <span class="slider-red-bold">Niquetribe</span> One Parallax Page'; ?></h2>
                                    <?= (isset($slide2)&&!empty($slide2['content']))?$slide2['content']:''; ?>
                                    <a href="#about" class="btn btn-default black-btn">Learn More</a>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END MAIN SLIDER -->

<div class="page-content">

<!-- ABOUT SECTION -->
<div class="section" id="about">
    <div class="container">
        <div class="section-heading">
            <h2 class="heading"><?= (isset($about['title'])&&!empty($about['title']))?$about['title']:"About Company";?></h2>
        </div>

        <div class="section-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="about-content">
                        <?= (isset($about['content'])&&!empty($about['content']))?'<h2 class="heading">'.$about['content'].'</h2>':"";?></h2>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- END ABOUT SECTION -->

<!-- SERVICES SECTION -->
<div class="section" id="service">
    <div class="container">
        <div class="section-heading">
            <h4 class="sub-heading"><?= (search_collection($sections, 'id', 1))?search_collection($sections, 'id', 1)['title']:'Creative Services'; ?></h4>
            <?= (search_collection($sections, 'id', 1))?'<h2 class="heading">'.search_collection($sections, 'id', 1)['content'].'</h2>':''; ?>
        </div>

        <div class="section-content">
            <div class="as-grid">

                <?php
                if(isset($services)&&count($services)>0){
                    foreach($services as $service){
                        ?>
                        <div class="as-grid-3">
                            <div class="single-service">
                                <div class="service-icon">
                                <img src="<?=(isset($service['logo'])&&!empty($service['logo']))?base_url('uploads/'.$service['logo']):asset_url('public/images/web-design.png'); ?>" class="hide-on-hover" style="max-height: 100px">
                                </div>
                            <h3 class="service-title"><?= (isset($service['title'])&&!empty($service['title']))?$service['title']:"";?></h3>
                            <div class="service-text"><?= (isset($service['content']))?$service['content']:"";?></div>
                        </div>
                        </div>
                        <?php
                    }
                }
                ?>


                <div class="clearfix"></div>

            </div>
        </div>
    </div>
</div>
<!-- END SERVICES SECTION -->

<!-- SKILLS SECTION -->
<div class="section" id="skills">
    <?php
    $skill=(search_collection($sections, 'id', 2))?search_collection($sections, 'id', 2):array();
    ?>
    <div class="container">

        <div class="section-content">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <div class="skills-content">
                        <div class="section-heading">
                            <h2 class="heading"><?= (isset($skill['title'])&&!empty($skill['title']))?$skill['title']:"Our Skills";?></h2>
                        </div>
                        <?= (isset($skill['content'])&&!empty($skill['content']))?$skill['content']:"";?>
                    </div>
                </div>

                <div class="col-sm-12 col-md-6">
                    <div class="skills-content">
                        <div class="progress-bar-content">
                            <?php
                            if(isset($skill_list)&&count($skill_list)>0){
                                foreach($skill_list as $info){
                                    ?>
                                    <div class="progressbar-label">
                                        <span class="p-label"><?= $info['skill_name']; ?></span>
                                        <span class="p-value"><?= isset($info['skill_percentage'])?$info['skill_percentage']:'90'; ?>%</span>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: <?= isset($info['skill_percentage'])?$info['skill_percentage']:'90'; ?>%;">
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END SKILLS SECTION -->

<!-- PROCESS SECTION -->
<div class="section" id="work-process">
    <div class="container">


        <div class="section-content">
            <div class="process-heading">
                <img src="<?php echo site_url('assets/public/images/work-process-bg.png'); ?>" class="work-process-img">
                <div class="section-heading vertical-heading">
                    <h4 class="sub-heading"><?= (isset($portfolio['title']))?$portfolio['title']:"How We do"; ?></h4>
                    <h2 class="heading"><?= (isset($portfolio['content']))?$portfolio['content']:""; ?></h2>
                </div>
            </div>
            <div class="row">

                <div class="col-md-8 col-md-offset-4">
                    <div class="process-tabs">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">

                            <li role="presentation" class="active">
                                <a href="#briefing" aria-controls="briefing" role="tab" data-toggle="tab">
                                            <span class="tab-img-title">
                                                <img src="<?php echo site_url('assets/public/images/briefing-gray.jpg'); ?>" class="hide-on-active">
                                                <img src="<?php echo site_url('assets/public/images/briefing-black.png'); ?>" class="show-on-active">
                                                <h3><?= (isset($portfolio['tab1_heading']))?$portfolio['tab1_heading']:"Briefing &amp; Ideas"; ?></h3>
                                            </span>
                                </a>
                            </li>

                            <li role="presentation">
                                <a href="#planning" aria-controls="planning" role="tab" data-toggle="tab">
                                            <span class="tab-img-title">
                                                <img src="<?php echo site_url('assets/public/images/planing-gray.jpg'); ?>" class="hide-on-active">
                                                <img src="<?php echo site_url('assets/public/images/planing-black.png'); ?>" class="show-on-active">
                                                <h3><?= (isset($portfolio['tab2_heading']))?$portfolio['tab2_heading']:"Planning &amp; Desiging"; ?></h3>
                                            </span>
                                </a>
                            </li>

                            <li role="presentation">
                                <a href="#developing" aria-controls="developing" role="tab" data-toggle="tab">
                                            <span class="tab-img-title">
                                                <img src="<?php echo site_url('assets/public/images/developing-gray.jpg'); ?>" class="hide-on-active">
                                                <img src="<?php echo site_url('assets/public/images/developing-black.png'); ?>" class="show-on-active">
                                                <h3><?= (isset($portfolio['tab3_heading']))?$portfolio['tab3_heading']:"Developing &amp; Testing"; ?></h3>
                                            </span>
                                </a>
                            </li>

                            <li role="presentation">
                                <a href="#execution" aria-controls="execution" role="tab" data-toggle="tab">
                                            <span class="tab-img-title">
                                                <img src="<?php echo site_url('assets/public/images/execution-gray.png'); ?>" class="hide-on-active">
                                                <img src="<?php echo site_url('assets/public/images/execution-black.png'); ?>" class="show-on-active">
                                                <h3><?= (isset($portfolio['tab4_heading']))?$portfolio['tab4_heading']:"Execution &amp; Ownership"; ?></h3>
                                            </span>
                                </a>
                            </li>
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="briefing">
                                <div class="process-content">
                                    <?= (isset($portfolio['tab1_content']))?$portfolio['tab1_content']:""; ?>
                                </div>
                            </div>

                            <div role="tabpanel" class="tab-pane" id="planning">
                                <div class="process-content">
                                    <?= (isset($portfolio['tab2_content']))?$portfolio['tab2_content']:""; ?>
                                </div>
                            </div>

                            <div role="tabpanel" class="tab-pane" id="developing">
                                <div class="process-content">
                                    <?= (isset($portfolio['tab3_content']))?$portfolio['tab3_content']:""; ?>
                                </div>
                            </div>

                            <div role="tabpanel" class="tab-pane" id="execution">
                                <div class="process-content">
                                    <?= (isset($portfolio['tab4_content']))?$portfolio['tab4_content']:""; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END PROCESS SECTION -->





<!-- CLIENT SECTION -->
<div class="section" id="clients">
    <div class="container">

        <div class="section-heading">
            <h4 class="sub-heading"><?= (search_collection($sections, 'id', 3))?search_collection($sections, 'id', 3)['title']:'Customers'; ?></h4>
            <h2 class="heading"><?= (search_collection($sections, 'id', 3))?search_collection($sections, 'id', 3)['content']:''; ?></h2>
        </div>

        <div class="client-slider-main">

            <div class="client-slider-navigation">
                <a href="#" class="previous_arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                <a href="#" class="next_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            </div>

            <div class="client-slider">
                <?php
                if(count($clients)>0){
                    foreach($clients as $client){
                        ?>
                        <div class="client-testimonial">
                            <div class="testimonial-content">
                                <p><?= $client['content']; ?></p>
                            </div>

                            <div class="client-info">
                                <img src="<?=(isset($client['logo'])&&!empty($client['logo']))?base_url('uploads/'.$client['logo']):asset_url('public/images/client-image.png'); ?>" class="img-circle" style="max-height: 70px;">
                                <h3 class="client-name"><?= $client['title']; ?></h3>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>

            </div>
        </div>
    </div>
</div>
<!-- END CLIENT SECTION -->

<!-- CALL TO ACTION SECTION -->
<div class="section" id="cta">
    <div class="container">
        <div class="section-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="cta-content">
                        <h2 class="cta-heading"><?= (search_collection($sections, 'id', 4))?search_collection($sections, 'id', 4)['title']:''; ?></h2>
                        <div class="cta-text"><?= (search_collection($sections, 'id', 4))?search_collection($sections, 'id', 4)['content']:''; ?></div>
                        <a href="#contact" class="btn btn-default cta-btn">Start a Project</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- END CALL TO ACTION SECTION -->

<!-- GET IN TOUCH SECTION -->
<div class="git-section" id="contact">
    <div class="container">
        <div class="as-grid-2">
            <div class="git-form">
                <h2 class="git-form-title">Get In Touch</h2>
                <form action="" method="post">
                    <div class="form-field">
                        <input type="text" name="name" placeholder="Your Name*" required="">
                    </div>

                    <div class="form-field">
                        <input type="email" name="email" placeholder="Email Address*" required="">
                    </div>

                    <div class="form-field">
                        <input type="url" name="website" placeholder="Your Website">
                    </div>

                    <div class="form-field">
                        <textarea name="message" placeholder="Write Message*" required=""></textarea>
                    </div>

                    <div class="form-field">
                        <button type="submit" class="btn btn-default git-btn">Send Message</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="as-grid-2">
            <div class="git-map">

                <iframe src="https://www.google.com/maps/embed/v1/place?q=<?= ((isset($settings['address'])&&!empty($settings['address'])))?$settings['address']:"New York";?>&zoom=17&key=AIzaSyASRKRDInNztty60yIEXZbSJq7mBwOGw2M" width="100%" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>


            </div>
        </div>

    </div>

    <div class="clearfix"></div>
</div>

<!-- END GET IN TOUCH SECTION -->


<div class="footer" id="newsletter">
    <div class="footer-top">
        <div class="container">
            <?php
            if($this->session->flashdata('success')){
                ?>
                <div class="alert alert-success">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <?= $this->session->flashdata('success'); ?>
                </div>
                <?php
            }
            ?>
            <?php
            if($this->session->flashdata('error')){
                ?>
                <div class="alert alert-danger">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <?= $this->session->flashdata('error'); ?>
                </div>
                <?php
            }
            ?>
            <div class="col-sm-6 col-md-4">
                <div class="widget">
                    <h3 class="widget-heading">Address</h3>
                    <ul class="widget-list icon-list">
                        <?= ((isset($settings['phone'])&&!empty($settings['phone'])))?'<li><a href="javascript:;"><i class="fa fa-phone" aria-hidden="true"></i>' .$settings['phone'].'</a></li>':""; ?>
                        <?= ((isset($settings['email'])&&!empty($settings['email'])))?'<li><a href="javascript:;"><i class="fa fa-envelope-o" aria-hidden="true"></i>' .$settings['email'].'</a></li>':""; ?>
                        <?= ((isset($settings['address'])&&!empty($settings['address'])))?'<li><a href="javascript:;"><i class="fa fa-map-marker" aria-hidden="true"></i>' .$settings['address'].'</a></li>':""; ?>
                        </ul>
                </div>
            </div>

            <div class="col-sm-6 col-md-4">
                <div class="widget">
                    <h3 class="widget-heading">Quick Links</h3>

                    <ul class="widget-list">
                        <li><a href="#myCarousel"><?= (search_collection($nav, 'id', 1))?search_collection($nav, 'id', 1)['title']:'Home'; ?></a></li>
                        <li><a href="#service"><?= (search_collection($nav, 'id', 2))?search_collection($nav, 'id', 2)['title']:'Our Services'; ?></a></li>
                        <li><a href="#about"><?= (search_collection($nav, 'id', 3))?search_collection($nav, 'id', 3)['title']:'About Us'; ?></a></li>
                        <li><a href="#contact"><?= (search_collection($nav, 'id', 4))?search_collection($nav, 'id', 4)['title']:'Contact Us'; ?></a></li>
                    </ul>
                </div>
            </div>



            <div class="col-sm-6 col-md-3">
                <div class="widget">
                    <h3 class="widget-heading">Newsletter</h3>
                    <div class="widget-form">
                        <form action="" method="post">
                            <i class="fa fa-paper-plane"></i>
                            <input type="email" name="email" placeholder="Email Address" class="footer-newsletter">
                        </form>
                    </div>
                    <ul class="widget-list footer-social-links">
                        <li><a href="<?= (isset($social_links['facebook'])&&!empty($social_links['facebook']))?$social_links['facebook']:'javascript:void(0);';?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="<?= (isset($social_links['twitter'])&&!empty($social_links['twitter']))?$social_links['twitter']:'javascript:void(0);';?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="<?= (isset($social_links['pinterest'])&&!empty($social_links['pinterest']))?$social_links['pinterest']:'javascript:void(0);';?>"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                        <li><a href="<?= (isset($social_links['linkedin'])&&!empty($social_links['linkedin']))?$social_links['linkedin']:'javascript:void(0);';?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        <li><a href="<?= (isset($social_links['google'])&&!empty($social_links['google']))?$social_links['google']:'javascript:void(0);';?>"><i class="fa fa-google" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <p>&copy;<?= (isset($settings['copyright_text'])&&!empty($settings['copyright_text']))?$settings['copyright_text']:"IT Services</a> 2017 All Rights Reserved.";?></p>
        </div>
    </div>
</div>
</div>

<script src="<?php echo site_url('assets/public/js/jquery-3.2.1.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/public/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/public/js/slick.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/public/js/custom.js'); ?>"></script>
</body>

</html>

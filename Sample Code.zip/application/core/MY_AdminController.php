<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class MY_AdminController extends CI_Controller {

    var $adminID = 0;
    var $adminData = NULL;
    var $js = array();
    var $css = array();
    var $globalSettings = NULL;
    var $adminPageTitle = 'Home';

    function __construct() {

        parent::__construct();
        $params = $this->router->fetch_method();
        $excluded_auth = array('login', 'forgotpassword', 'resetpassword');
        $this->load->model('Admin_Model', 'Admin');
        $this->load->helper('email');

        if (!in_array($params, $excluded_auth)) {

            $this->adminAuthenticate();
        }

//        $this->initializeSideNavigation();
    }

    public function adminAuthenticate() {
        if ($this->session->userdata('admin_session')) {
            $adminSession = $this->session->userdata('admin_session');
            $this->accessRule = $this->Admin->getAccessRule(base64_decode($adminSession['id']));
            if (isset($adminSession['id'])) {
                $isAdminExists = $this->Admin->getAdminById(base64_decode($adminSession['id']), 'id');
                if ($isAdminExists) {
                    $this->adminData = $this->Admin->getAdminById(base64_decode($adminSession['id']));
                    $this->adminID = $this->adminData['id'];
                    return;
                }
            }
        }

        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')) {
            echo '<script type="text/javascript">top.location.href="' . site_url('/admin/login') . '";</script>';
            exit;
        }
        redirect(site_url('/admin/login'));
    }

    public function verifySessionExists() {
        if ($this->session->userdata('admin_session')) {
            $adminSession = $this->session->userdata('admin_session');
            if (isset($adminSession['id'])) {
                $isAdminExists = $this->Admin->getAdminById(base64_decode($adminSession['id']), 'id');
                if ($isAdminExists) {
                    return true;
                }
            }
        }
        return false;
    }

}


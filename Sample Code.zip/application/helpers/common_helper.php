<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Mazhar
 * Date: 2/12/17
 * Time: 7:23 PM
 * To change this template use File | Settings | File Templates.
 */
if (!function_exists('link_js')) {
    function link_js($file) {
        return '<script type="text/javascript" src="' . base_url( 'assets/'.$file) . '"></script>';
    }
}

if (!function_exists('link_css')) {
    function link_css($file, $id = '') {
        return '<link href="' . base_url('assets/'.$file) . '" rel="stylesheet" type="text/css" '.( $id == '' ? '' : 'id="'.$id.'"' ).'  />';
    }
}

if (!function_exists('asset_url')) {
    function asset_url($file) {
        return  base_url('assets/'.$file);
    }
}
if (!function_exists('send_email')) {
    function send_email($emailTo, $emailFrom, $emailSubject, $emailBody) {


        $CI = & get_instance();
        $CI->load->library('Email');
        $smtp=$CI->db->query("SELECT * from smtp_settings Where id='1'")->row_array();
        if($smtp){
            $emailConfig = array();
            $emailConfig['protocol'] = 'smtp';
            $emailConfig['mailtype'] = 'html';
            $emailConfig['charset'] = 'utf-8';
            //$emailConfig['smtp_crypto'] = 'tls';

            $emailConfig['smtp_host'] = (isset($smtp['host']))?$smtp['host']:'';
            $emailConfig['smtp_user'] = (isset($smtp['username']))?$smtp['username']:'';  //fahad.malik.mazhar
            $emailConfig['smtp_pass'] = (isset($smtp['password']))?base64_decode($smtp['password']):'';  //Comsats@123
            $emailConfig['smtp_port'] =  (isset($smtp['port']))?$smtp['port']:'';

            $CI->email->initialize($emailConfig);
            $CI->email->from($emailFrom);
            $CI->email->to($emailTo);
            $CI->email->subject($emailSubject);
            $CI->email->message($emailBody);
            try {

                $CI->email->send();

                $result=$CI->email->print_debugger(array('headers'));
//        print_r($result);
//        exit;
                $CI->email->clear(TRUE);
                return true;
            } catch (Exception $ex) {

            }
            $CI->email->clear(TRUE);
        }
    }
}

function search_collection($input, $field, $value)
{
    foreach($input as $key => $product)
    {
        if ( $product[$field] == $value )
            return $product;
    }
    return false;
}

function pull_images($input){
    $images=[];
    if(isset($input['image1'])&&!empty($input['image1']))
        $images[]=$input['image1'];
    if(isset($input['image2'])&&!empty($input['image2']))
        $images[]=$input['image2'];
    if(isset($input['image3'])&&!empty($input['image3']))
        $images[]=$input['image3'];
    if(isset($input['image4'])&&!empty($input['image4']))
        $images[]=$input['image4'];
    if(isset($input['image5'])&&!empty($input['image5']))
        $images[]=$input['image5'];
    if(isset($input['image6'])&&!empty($input['image6']))
        $images[]=$input['image6'];
    return $images;
}

function hexToRgb($hex, $alpha = false) {
    $hex      = str_replace('#', '', $hex);
    $length   = strlen($hex);
    $rgb['r'] = hexdec($length == 6 ? substr($hex, 0, 2) : ($length == 3 ? str_repeat(substr($hex, 0, 1), 2) : 0));
    $rgb['g'] = hexdec($length == 6 ? substr($hex, 2, 2) : ($length == 3 ? str_repeat(substr($hex, 1, 1), 2) : 0));
    $rgb['b'] = hexdec($length == 6 ? substr($hex, 4, 2) : ($length == 3 ? str_repeat(substr($hex, 2, 1), 2) : 0));
    if ( $alpha ) {
        $rgb['a'] = $alpha;
    }
    return $rgb['r'].','.$rgb['g'].','.$rgb['b'];
}
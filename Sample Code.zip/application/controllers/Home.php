<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('Content_Model', 'Content');
        $this->load->library('form_validation');
    }

    public function index()
    {
        if ($this->input->post()) {
            if($this->input->post('message')){
                $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
                $this->form_validation->set_rules('name', 'name', 'trim|required');
                $this->form_validation->set_rules('message', 'message', 'trim|required');
                $this->form_validation->set_rules('subject', 'Website', 'trim|required');
                if ($this->form_validation->run()) {
                    $to_email = $this->Content->get_where('email', array('id' => 1), 'settings');
                    send_email($to_email['email'],$this->input->post('email'),$this->input->post('subject'),$this->input->post('message'));
                    $this->session->set_flashdata('success', "Message Sent Successfully.");
                } else {
                    $this->session->set_flashdata('error', validation_errors());
                }
            }else{
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            if ($this->form_validation->run()) {
                $email = $this->input->post('email');
                $mail_exist = $this->Content->get_where('count', array('email' => $email), 'mail_list');
                $this->session->set_flashdata('success', "You are subscribed successfully.");
                if ($mail_exist == 0) {
                    $this->Content->save('mail_list', array('email' => $email, 'created_at' => time()));
                }
            } else {
                $this->session->set_flashdata('error', validation_errors());
            }
            }
            redirect(base_url('#contact'));
        }
        $view_data = array();
        $view_data['social_links'] = $this->Content->get_social_links();
        $view_data['nav'] = $this->Content->get('menu', 'id,title');
        $slide = $this->Content->get('slider', 'id,title,content,image');
        $view_data['slide1'] = search_collection($slide, 'id', 1);
        $view_data['slide2'] = search_collection($slide, 'id', 2);
        $view_data['about'] = $this->Content->get_where('*', array('id' => 1), 'about_page');
        $view_data['sections'] = $this->Content->get('sections');
        $view_data['services'] = $this->Content->get('services');
//        $view_data['skill_list'] = $this->Content->get('skills');
//        $view_data['clients'] = $this->Content->get('clients');
//        $view_data['portfolio'] = $this->Content->get_where('*', array('id' => 1), 'portfolio');
        $view_data['settings'] = $this->Content->get_where('*', array('id' => 1), 'settings');
        $tweet = $this->Content->get_where('name,title', array('id' => 1), 'twitter_user');
        $view_data['tweet_title']=$tweet['title'];
        if (isset($tweet['name']) && !empty($tweet['name'])) {
            @$response = simplexml_load_file("https://twitrss.me/twitter_user_to_rss/?user=" . $tweet['name']);
            if ($response) {
                $view_data['tweet_username']=$tweet['name'];
                $view_data['tweet_image'] = isset($response->channel->image->url) ? $response->channel->image->url : '';
                if (isset($response->channel->item)) {
                    $view_data['tweets'] = $response;
                }
            }
        }
        $this->load->view('home_new',$view_data);
    }


}

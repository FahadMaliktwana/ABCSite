<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Admin extends MY_AdminController {

    function __construct() {
        parent::__construct();
        $this->layout = 'admin_inner';

    }

    public function index() {
        if (!$this->verifySessionExists())
            redirect(site_url('admin/login'));
        $view_data['page']='dashboard';
        $this->load->view("admin/dashboard",$view_data);
    }

    public function login() {
        $this->layout='admin_public';
        if ($this->verifySessionExists())
            redirect(site_url('admin'));
        $loginError = '';
        $this->load->library('form_validation');
        if ($this->input->post('admin_login_form')) {
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'required');
            if (!($this->form_validation->run() == FALSE)) {

                //Process Vendor Login
                $adminResult = $this->Admin->validateAdminLogin($this->input->post('email'), $this->input->post('password'));
                if ($adminResult) {
                    if ($adminResult['is_active'] == 1) {
                        $this->adminLogin($adminResult['id']);
                    } else {
                        $loginError = '<p>Your Account is Currently Inactive.</p>';
                    }
                } else {
                    $loginError = '<p>Invalid email/password provided.</p>';
                }
            }
        }
        $this->load->view("admin/login", array('loginError' => $loginError));
    }

    public function adminLogin($adminID) {
        $adminSession = array();
        $adminSession['id'] = base64_encode($adminID);
        $this->session->set_userdata('admin_session', $adminSession);
        $access=$this->Admin->getAccessRule($adminID);
        if($access)
            if($access['access_rule']=='admin'){
                redirect(site_url('admin'));
            }
            else{

                redirect(site_url('admin/login'));
            }
    }



    function logout(){
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
        $this->output->set_header("Pragma: no-cache");
        $this->session->sess_destroy();
        redirect(site_url('admin/login'));
    }



    public function forgotpassword($success = '') {
        if ($this->verifySessionExists())
            redirect(site_url('admin'));
        $loginError = '';
        $this->layout = 'admin_public';
        $this->load->library('form_validation');
        if ($this->input->post('admin_forgot_form')) {
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            if (!($this->form_validation->run() == FALSE)) {
                $adminResult = $this->Admin->getAdminByEmail($this->input->post('email'));
                if ($adminResult) {
                    $adminData = array();
                    $key = md5($this->input->post('email') . '-' . $adminResult['id']);
                    $adminData['recover_password_token'] = $key . '-|-' . time() . '-|-valid';
                    $this->Admin->updateAdmin($adminData, $adminResult['id']);
                    $mail_template="Hi ".$adminResult['last_name'].',<br> Please Click <a href="'.site_url('admin/resetpassword/' . $key).'">Here</a> To Reset your passwords.<br><br>Thanks<br>Regards CMS support Team.';
                    send_email($adminResult['email'], 'support@cms.com','CMS Password Reset', $mail_template );
                    redirect(site_url('admin/forgotpassword/1'));
                } else {
                    $loginError = '<p>Email Does Not Exist!</p>';
                }
            }
        }
        $this->load->view("admin/forgotpassword", array('loginError' => $loginError, 'success' => $success));
    }



    public function changepassword() {
        if ($this->verifySessionExists())
            redirect(site_url('admin'));
        $loginError = '';
        $this->layout='admin_public';
        $this->sideNavigation['staff']['Selected'] = true;
        $this->sideSubNavigation['staff']['add_staff']['Selected'] = true;
        $this->load->library('form_validation');
        if ($this->input->post('admin_change_form')) {
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[password]');
            if (!($this->form_validation->run() == FALSE)) {
                $adminData = array();
                $adminData['password'] = md5($this->input->post('password'));
                $this->Admin->updateAdmin($adminData, $this->adminID);
                redirect(site_url('admin'));
            }
        }
        $this->load->view("admin/changepassword");
    }

    public function resetpassword($code = '') {
        if ($this->verifySessionExists())
            redirect(site_url('admin'));
        $loginError = '';
        $this->layout = 'admin_public';
        list($resetCodeValid, $resetCodeError, $adminID) = $this->verifyResetCode($code);
        $this->load->library('form_validation');
        if ($this->input->post('admin_reset_form') && $resetCodeValid) {
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[password]');
            if (!($this->form_validation->run() == FALSE)) {
                $adminData2 = $this->Admin->getStaff($adminID);
                $adminData = array();
                $adminData['recover_password_token'] = $code . '-|-' . time() . '-|-used';
                $adminData['password'] = md5($this->input->post('password'));
                $this->Admin->updateAdmin($adminData, $adminID);
                $this->adminLogin($adminID);
            }
        }
        if(!$resetCodeValid)
            show_404();
        $this->load->view("admin/resetpassword", array('rCode' => $code, 'loginError' => $loginError, 'resetCodeValid' => $resetCodeValid, 'resetCodeError' => $resetCodeError));
    }

    public function verifyResetCode($resetCode) {
        $isValid = false;
        $errorType = '';
        $adminID = 0;
        if (!trim($resetCode)) {
            $errorType = 'Missing';
        } else {
            $sqlQuery = "SELECT id, recover_password_token FROM admin WHERE recover_password_token LIKE '" . $this->db->escape_str($resetCode) . "%'";
            $sqlResults = $this->db->query($sqlQuery)->row_array();
            if ($sqlResults) {
                if (strpos($sqlResults['recover_password_token'], 'valid') > 0) {
                    $isValid = true;
                    $adminID = $sqlResults['id'];
                } else {
                    $errorType = 'Expired';
                }
            } else {
                $errorType = 'Invalid';
            }
        }
        return array($isValid, $errorType, $adminID);
    }

}
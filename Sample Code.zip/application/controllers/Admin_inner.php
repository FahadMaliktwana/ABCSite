<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Mazhar
 * Date: 4/12/17
 * Time: 3:38 PM
 * To change this template use File | Settings | File Templates.
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Admin_inner extends MY_AdminController {

    function __construct() {
        parent::__construct();
        $this->load->model('Content_Model', 'Content');
        $this->load->library('form_validation');
        $this->layout = 'admin_inner';
    }

    function social_links(){

        if($this->input->post()){
            $content=$this->Content->get_social_links();
            $this->form_validation->set_rules('facebook', 'Facebook Url', 'trim|valid_url');
            $this->form_validation->set_rules('twitter', 'Twitter Url', 'trim|valid_url');
            $this->form_validation->set_rules('linkedin', 'LinkedIn Url', 'trim|valid_url');
//            $this->form_validation->set_rules('google', 'Google Url', 'trim|valid_url');
//            $this->form_validation->set_rules('pinterest', 'Pinterest Url', 'trim|valid_url');
            if ($this->form_validation->run())
            {
                $db_data=array(
                    'facebook'=>$this->input->post('facebook'),
//                    'google'=>$this->input->post('google'),
                    'twitter'=>$this->input->post('twitter'),
                    'linkedin'=>$this->input->post('linkedin'),
//                    'pinterest'=>$this->input->post('pinterest')
                );
                if($content){
                    $db_data['updated_at']=time();
                    $this->Content->update($content['id'],$db_data,'social_links');
                }else{
                    $db_data['id']=1;
                    $db_data['created_at']=time();
                    $db_data['updated_at']=time();
                    $this->Content->save('social_links',$db_data);
                }
                $view_data['success']="Record Saved successfully.";
            }
        }
        $view_data['data']=$this->Content->get_social_links();
        $view_data['page']='social_links';
        $this->load->view('admin/social_links',$view_data);
    }

    function nav($id){
        if($id<=4 && $id>0){
            if($this->input->post()){
                $menu_content=$this->Content->get_where('*' ,array('id'=>$id),'menu');
                $this->form_validation->set_rules('title', 'Title', 'trim|required|callback_verifyTitle');
                if ($this->form_validation->run())
                {
                    $db_data=array(
                        'title'=>strip_tags($this->input->post('title'),'<span><b><i><em><strong><br><em>')
                    );

                    if($menu_content){
                        $db_data['updated_at']=time();
                        $this->Content->update($id,$db_data,'menu');
                    }else{
                        $db_data['id']=$id;
                        $db_data['created_at']=time();
                        $db_data['updated_at']=time();
                        $this->Content->save('menu',$db_data);
                    }
                    $view_data['success']="Record Saved successfully.";
                }
            }
            $view_data['data']=$this->Content->get_where('*' ,array('id'=>$id),'menu');
            if(!isset($view_data['data']['title']) || empty($view_data['data']['title'])){
                if($id==1){
                    $view_data['data']['title']='Home';
                }else if($id==2){
                    $view_data['data']['title']='Our Services';
                }else if($id==3){
                    $view_data['data']['title']='About Us';
                }else if($id==4){
                    $view_data['data']['title']='Contact';
                }
            }
            $view_data['page']='menu'.$id;
            $view_data['id']=$id;
            $this->load->view('admin/nav_content',$view_data);
        }else{
            redirect(base_url('admin'));
            exit;
        }
    }

    function slider($id){
        if($id<=2 && $id>0){
            if($this->input->post()){
                $slider_content=$this->Content->get_where('*' ,array('id'=>$id),'slider');
                $this->form_validation->set_rules('title', 'Title', 'trim|required');
                $this->form_validation->set_rules('content', 'Content', 'trim');
                if ($this->form_validation->run())
                {
                    $db_data=array(
                        'title'=>strip_tags($this->input->post('title'),'<span><b><i><em><strong><br><em>'),
                        'content'=>$this->input->post('content')
                    );

                    $upload_status=$this->file_upload();
                    if($upload_status['status']==200){

                        if ($slider_content) {
                            if($upload_status['logo']!=''){
                                if($slider_content['image']!='')
                                    @unlink(BASEDIR.$slider_content['image']);
                                $db_data['image']=$upload_status['logo'];
                            }
                            $db_data['updated_at'] = time();
                            $this->Content->update($id, $db_data, 'slider');
                        } else {
                            $db_data['id']=$id;
                            $db_data['image']=$upload_status['logo'];
                            $db_data['updated_at'] = time();
                            $db_data['created_at'] = time();
                            $this->Content->save('slider', $db_data);
                        }
                        $view_data['success']="Record Saved successfully.";
                    }else{
                        $view_data['error']=$upload_status['message'];
                    }
                }
            }
            $view_data['data']=$this->Content->get_where('*' ,array('id'=>$id),'slider');
            $view_data['page']='slider'.$id;
            $view_data['id']=$id;
            $this->load->view('admin/slider',$view_data);
        }else{
            redirect(base_url('admin'));
            exit;
        }

    }

    function about(){
        if($this->input->post()){
            $about_content=$this->Content->get_where('*' ,array('id'=>1),'about_page');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
//            $this->form_validation->set_rules('sub_title', 'Sub Title', 'trim');
            $this->form_validation->set_rules('content', 'Content', 'trim|required');
            if ($this->form_validation->run())
            {
                $db_data=array(
                    'title'=>strip_tags($this->input->post('title'),'<span><b><i><em><strong><br><em>'),
//                    'sub_title'=>strip_tags($this->input->post('sub_title'),'<span><b><i><em><strong><br><em>'),
                    'content'=>$this->input->post('content')
                );

                $upload_status=$this->file_upload();
                if($upload_status['status']==200){
                    if ($about_content) {
                        if($upload_status['logo']!=''){
                            if($about_content['image']!='')
                                @unlink(BASEDIR.$about_content['image']);
                            $db_data['image']=$upload_status['logo'];
                        }
                        $db_data['updated_at'] = time();
                        $this->Content->update(1, $db_data, 'about_page');
                    } else {
                        $db_data['id']=1;
                        $db_data['image']=$upload_status['logo'];
                        $db_data['created_at'] = time();
                        $db_data['updated_at'] = time();
                        $this->Content->save('about_page', $db_data);
                    }
                    $view_data['success']="Record Saved successfully.";
                }else{
                    $view_data['error']=$upload_status['message'];
                }
            }
        }

        $view_data['data']=$this->Content->get_where('*' ,array('id'=>1),'about_page');
        $view_data['page']='about';
        $this->load->view('admin/about',$view_data);
    }

    function service_content(){
        if($this->input->post()){
            $content=$this->Content->get_where('*' ,array('id'=>1),'sections');
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Sub Title', 'trim');
            if ($this->form_validation->run())
            {
                $db_data=array(
                    'title'=>strip_tags($this->input->post('title'),'<span><b><i><em><strong><br><em>'),
                    'content'=>$this->input->post('content')
                );
                    if ($content) {
                        $db_data['updated_at'] = time();
                        $this->Content->update(1, $db_data, 'sections');
                    } else {
                        $db_data['id']=1;
                        $db_data['created_at'] = time();
                        $db_data['updated_at'] = time();
                        $this->Content->save('sections', $db_data);
                    }
                    $view_data['success']="Record Saved successfully.";
            }
        }

        $view_data['data']=$this->Content->get_where('*' ,array('id'=>1),'sections');
        $view_data['page']='service_content';
        $this->load->view('admin/service_content',$view_data);
    }

    function services(){
        $view_data['data']=$this->Content->get('services');
        $view_data['page']='services';
        $this->load->view('admin/services',$view_data);
    }

    function add_service($id=''){
        if($this->input->post()){
            $this->form_validation->set_rules('title', 'Title', 'trim|required');
            $this->form_validation->set_rules('content', 'Content', 'trim|required');
            if ($this->form_validation->run())
            {
                $db_data=array(
                    'title'=>strip_tags($this->input->post('title'),'<span><b><i><em><strong><br><em>'),
                    'content'=>$this->input->post('content')
                );

                $upload_status=$this->file_upload();
                if($upload_status['status']==200){
                    if ($id) {
                        if($upload_status['logo']!=''){
                            $content=  $this->Content->get_where('*' ,array('id'=>$id),'services');
                            if($content['logo']!='')
                                @unlink(BASEDIR.$content['logo']);
                            $db_data['logo']=$upload_status['logo'];
                        }
                        $db_data['updated_at'] = time();
                        $this->Content->update($id, $db_data, 'services');
                    } else {
                        $db_data['logo']=$upload_status['logo'];
                        $db_data['created_at'] = time();
                        $db_data['updated_at'] = time();
                        $this->Content->save('services', $db_data);
                    }
                    //$view_data['success']="Record Saved successfully.";
                    $this->session->set_flashdata('success','Record Saved successfully.');
                    redirect(base_url('admin/services'));
                }else{
                    $view_data['error']=$upload_status['message'];
                }
            }
        }
        if($id)
            $view_data['data']=$this->Content->get_where('*' ,array('id'=>$id),'services');
        $view_data['page']='services';
        $this->load->view('admin/addservice',$view_data);
    }



    function delete_service($id){
        $this->Content->delete('services',$id);
        $this->session->set_flashdata('success','Record Deleted successfully.');
        redirect(base_url('admin/services'));
    }




    function newsletter(){
        $view_data['data']=$this->Content->get('mail_list');
        $view_data['page']='newsletter';
        $this->load->view('admin/newsletters',$view_data);
    }
//    function request(){
//        $view_data['data']=$this->Content->get('request_list','','id');
//        $view_data['page']='request';
//        $this->load->view('admin/requests',$view_data);
//    }

    function profile(){
        if($this->input->post('profile')){
            $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|callback_verifyAdminEmailExistance[' . $this->adminID . ']');
            $view_data['active']='profile';
            if ($this->form_validation->run()){
                $db_data=array('first_name'=>$this->input->post('first_name'),'last_name'=>$this->input->post('last_name'),'email'=>$this->input->post('email'));
                $this->Content->update($this->adminID,$db_data,'admin');
                $view_data['success']="Profile Updated successfully.";
            }
        }else if ($this->input->post('admin_change_form')) {
            $view_data['active']='password';
            $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[password]');
            if (!($this->form_validation->run() == FALSE)) {
                $adminData = array();
                $adminData['password'] = md5($this->input->post('password'));
                $this->Content->update($this->adminID,$adminData,'admin');
                $view_data['success']="Password Changed Successfully";
            }
        }
        $view_data['admin']=$this->Content->get_where('first_name,last_name,email' ,array('id'=>$this->adminData['id']),'admin');
        $view_data['page']='profile';
        $this->load->view('admin/profile',$view_data);
    }

    function setting(){
        if($this->input->post()){
            $content=$this->Content->get_where('*' ,array('id'=>1),'settings');
            $this->form_validation->set_rules('site_email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('site_title', 'Site Title', 'trim|required');
//            $this->form_validation->set_rules('address', 'address', 'trim|required');
//            $this->form_validation->set_rules('phone', 'Phone Number', 'trim');
            $this->form_validation->set_rules('copyright_text', 'Copy Right Text', 'trim|required');
            if ($this->form_validation->run())
            {
                $upload_status=$this->file_upload();
                if($upload_status['status']==200){
                    $db_data=array(
                        'email'=>$this->input->post('site_email'),
                        'site_title'=>strip_tags($this->input->post('site_title'),'<span><b><i><em><strong><br><em>'),
//                        'address'=>$this->input->post('address'),
//                        'phone'=>$this->input->post('phone'),
                        'copyright_text'=>strip_tags($this->input->post('copyright_text'),'<span><b><i><em><strong><br><em>')
                    );
                    if($content){
                        if($upload_status['logo']!=''){
                            if($content['logo']!='')
                            @unlink(BASEDIR.$content['logo']);
                            $db_data['logo']=$upload_status['logo'];
                        }
                        $db_data['updated_at']=time();
                        $this->Content->update($content['id'],$db_data,'settings');
                    }else{
                        $db_data['id']=1;
                        $db_data['logo']=$upload_status['logo'];
                        $db_data['created_at']=time();
                        $db_data['updated_at']=time();
                        $this->Content->save('settings',$db_data);
                    }
                    $view_data['success']="Record Saved successfully.";
                }else{
                    $view_data['error']=$upload_status['message'];
                }
            }
        }
        $view_data['data']=$this->Content->get_where('*' ,array('id'=>1),'settings');
        $view_data['page']='setting';
        $this->load->view('admin/settings',$view_data);
    }

    private function file_upload(){
        if (isset($_FILES['image'])&&$_FILES['image']['size'] > 0) {
            $time = time();
            $file = $time . $_FILES['image']['name'];
            $fileName = str_replace("/\s+/", "_", $file);
            $config['file_name'] = $fileName;
            $config['upload_path'] = BASEDIR ;
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = '2048';
            $this->load->library('upload', $config);
            $response=array();
            if ($this->upload->do_upload('image')) {
                $upData = $this->upload->data();
                $name = $upData['file_name'];
                $response['status']=200;
                $response['logo'] = $name;
            } else {
                $response['status']=400;
                $response['message'] = $this->upload->display_errors();
            }

        }else{
            $response['status']=200;
            $response['logo'] = '';
        }
        return $response;
    }

    private function multi_file_upload(){
        $list=array();
        for($i=1; $i<=6; $i++) {
            if (isset($_FILES['image'.$i])&&$_FILES['image'.$i]['size'] > 0) {
                $time = time();
                $file = $time . $_FILES['image'.$i]['name'];
                $fileName = str_replace("/\s+/", "_", $file);
                $config['file_name'] = $fileName;
                $config['upload_path'] = BASEDIR ;
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = '2048';
                $this->load->library('upload', $config);
                $response=array();
                if ($this->upload->do_upload('image'.$i)) {
                    $upData = $this->upload->data();
                    $list[]=$upData['file_name'];
                } else {
                    foreach($list as $val){
                        if($val!="")
                            @unlink(BASEDIR.$val);
                    }
                    $response['status']=400;
                    $response['message'] = $this->upload->display_errors();
                    return $response;
                }

            }else{
                $list[]='';
            }
        }
        $response['status']=200;
        $response['logos'] = $list;
        return $response;
    }

    public function verifyAdminEmailExistance($email, $adminId) {
        $isValid = false;

        $sqlQuery = "SELECT a.email FROM admin a WHERE a.email = '" . $this->db->escape_str($email) . "' AND id !='$adminId'";

        $sqlResults = $this->db->query($sqlQuery)->row_array();

        if ($sqlResults) {
            $this->form_validation->set_message('verifyAdminEmailExistance', 'This %s is already in use.');
        } else {
            $isValid = true;
        }
        return $isValid;
    }


    function verifyUsername($username)
    {
        $isValid = false;
        if(empty($username) || preg_match('/^[A-Za-z0-9_]{1,15}$/', $username)){
            $isValid=true;
        }else{
            $this->form_validation->set_message('verifyUsername', 'Not a valid twitter username.');
        }
        return $isValid;
    }

    function verifyTitle($title)
    {
        $isValid = false;
        $title=trim(strip_tags($title),' &nbsp;');
        if(!empty($title)){
            $isValid=true;
        }else{
            $this->form_validation->set_message('verifyTitle', 'Title Field is required.');
        }
        return $isValid;
    }

    function smtp_settings(){

        if($this->input->post()){
            $content=$this->Content->get_where('*' ,array('id'=>'1'),'smtp_settings');
            $this->form_validation->set_rules('host', 'SMTP Host', 'trim|required');
            $this->form_validation->set_rules('username', 'SMTP Username', 'trim|required');
            $this->form_validation->set_rules('password', 'SMTP Password', 'trim|required');
            $this->form_validation->set_rules('port', 'SMTP Port', 'trim|required|integer');
            if ($this->form_validation->run())
            {
                $db_data=array(
                    'host'=>$this->input->post('host'),
                    'username'=>$this->input->post('username'),
                    'password'=>base64_encode($this->input->post('password')),
                    'port'=>$this->input->post('port')
                );
                if($content){
                    $db_data['updated_at']=time();
                    $this->Content->update($content['id'],$db_data,'smtp_settings');
                }else{
                    $db_data['id']=1;
                    $db_data['created_at']=time();
                    $db_data['updated_at']=time();
                    $this->Content->save('smtp_settings',$db_data);
                }
                $view_data['success']="Record Saved successfully.";
            }
        }
        $view_data['data']=$this->Content->get_social_links();
        $view_data['data']=$this->Content->get_where('*' ,array('id'=>'1'),'smtp_settings');
        $view_data['page']='smtp';
        $this->load->view('admin/smtp',$view_data);
    }

    function twitter(){
        if($this->input->post()){
            $content=$this->Content->get_where('name' ,array('id'=>1),'twitter_user');
            $this->form_validation->set_rules('title','Section Title', 'trim');
            $this->form_validation->set_rules('username', 'User Name', 'trim|callback_verifyUsername');
            if (!($this->form_validation->run() == FALSE)) {
                $user=$this->input->post('username');
                if(!empty($user))
                @$response=simplexml_load_file("https://twitrss.me/twitter_user_to_rss/?user=".$user);
                if(empty($user) || isset($response)){
                    $db_data=array(
                        'name'=>$user,
                        'title'=>$this->input->post('title')
                    );
                    if($content){
                        $db_data['updated_at']=time();
                        $this->Content->update(1,$db_data,'twitter_user');
                    }else{
                        $db_data['id']=1;
                        $db_data['created_at']=time();
                        $db_data['updated_at']=time();
                        $this->Content->save('twitter_user',$db_data);
                    }
                    $view_data['success']="Record Saved successfully.";
                }else{
                    $view_data['error']="Not a valid twitter username.";
                }
            }
        }
        $view_data['data']=$this->Content->get_where('title,name' ,array('id'=>1),'twitter_user');
        $view_data['page']='twitter';
        $this->load->view('admin/twitter',$view_data);

    }
}
<?php

class Content_Model extends CI_Model {

    public function get_social_links() {
        $sqlQuery = "SELECT * FROM social_links WHERE id = '1'";
        $sqlResult = $this->db->query($sqlQuery)->row_array();
        return $sqlResult;
    }

    public function save($table,$data) {
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    public function update($row_id, $data,$table) {
        $this->db->where('id', $row_id);
        return $this->db->update($table, $data);
    }

    public function get_where($select='' ,$where = '',$table)
    {
        if((count($where) > 0 && is_array($where)) || (!is_array($where) && $where != '' ) )
        {
            $this->db->where($where);
        }

        if($select == 'count')
        {
            return $this->db->count_all_results($table);
        }
        else
        {
            if($select != '')
            {
                $this->db->select($select);
            }
            return $this->db->get($table)->row_array();
        }
    }

    public function get($table,$select='',$order_by=''){
        if($select != '')
        {
            $this->db->select($select);
        }
        if($order_by!=''){
            $this->db->order_by($order_by, 'DESC');
        }
        return $this->db->get($table)->result_array();
    }

    public function delete($table,$id) {
        return $this->db->delete($table, array('id' => $id));
    }

}

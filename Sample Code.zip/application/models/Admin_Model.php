<?php

class Admin_Model extends CI_Model {

    public function getAdminById($adminID, $fields = '*') {
        $sqlQuery = "SELECT " . $fields . " FROM admin WHERE id = '" . $this->db->escape_str($adminID) . "'";
        $sqlResult = $this->db->query($sqlQuery)->row_array();
        return $sqlResult;
    }

    public function getAccessRule($id){
        $query="select access_rule from admin where id='".$this->db->escape_str($id)."'";
        $result=$this->db->query($query)->row_array();
        return $result;
    }


    public function validateAdminLogin($adminEmail, $adminPassword) {
        $sqlQuery = "SELECT id, is_active FROM admin WHERE email = '" . $this->db->escape_str($adminEmail) . "' AND password = '" . $this->db->escape_str(md5($adminPassword)) . "'";
        $sqlResult = $this->db->query($sqlQuery)->row_array();
        return $sqlResult;
    }

    public function getAdminByEmail($adminEmail, $fields = '*') {
        $sqlQuery = "SELECT " . $fields . " FROM admin WHERE email = '" . $this->db->escape_str($adminEmail) . "'";
        $sqlResult = $this->db->query($sqlQuery)->row_array();
        return $sqlResult;
    }

    public function updateAdmin($adminArray, $adminID, $updated = true) {
        $this->db->where('id', $adminID);
        $this->db->update('admin', $adminArray);
    }

    public function getStaff($adminID, $fields = '*') {
        $sqlQuery = "SELECT " . $fields . " FROM admin WHERE id = '" . $this->db->escape_str($adminID) . "'";
        $sqlResult = $this->db->query($sqlQuery)->row_array();
        return $sqlResult;
    }

}
